# macOS cursor pack for Windows

## How to use it:

1. Select a folder with the desired size
2. Right click Install.inf and click «Install» 
3. Go to Control Panel → Mouse and choose «macOS Cursors» («macOS Cursors L», «macOS Cursors XL») scheme. 
4. Apply and enjoy the best cursors ever!

## Authors

Zaid Ayyaz (azad.co)

## License

Free to use
